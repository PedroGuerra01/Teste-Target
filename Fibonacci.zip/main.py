def verifica_fibonacci(numero):

  fib_ant = 0
  fib_atual = 1

  while fib_atual < numero:

      fib_prox = fib_ant + fib_atual


      if fib_prox == numero:
          return True

      fib_ant = fib_atual
      fib_atual = fib_prox


  return False

def main():
  numero = int(input("Informe um número para verificar se pertence à sequência de Fibonacci: "))

  if verifica_fibonacci(numero):
      print(f"O número {numero} pertence à sequência de Fibonacci.")
  else:
      print(f"O número {numero} não pertence à sequência de Fibonacci.")

if __name__ == "__main__":
  main()
